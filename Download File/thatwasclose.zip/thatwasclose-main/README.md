That was close - a game what you have to quit to win

This game isn't that easy to close. But that's what you're supposed to do... Try to quit the game by solving small puzzles! The gameplay is about 5 minutes long and it works with pygame. I hope you have much fun playing this game!

You need to have python pygame installed!
If you haven't, install it via "winget install -e --id Python.Python.3.11" and "pip install pygame"

To start the game, execute (only) that was close.py

Update Changelog:
v1.1
  New languages: Now theres English and German. You can select your language at the start.
